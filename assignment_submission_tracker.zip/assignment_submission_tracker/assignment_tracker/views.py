from django.shortcuts import render, get_object_or_404, redirect
from .models import Assignment
from .forms import AssignmentForm

# Read - List
def assignment_list(request):
    assignments = Assignment.objects.all()
    return render(request, 'tracker/assignment_list.html', {'assignments': assignments})

# Read - Detail
def assignment_detail(request, pk):
    assignment = get_object_or_404(Assignment, pk=pk)
    return render(request, 'tracker/assignment_detail.html', {'assignment': assignment})

# Create
def assignment_create(request):
    if request.method == "POST":
        form = AssignmentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('assignment_list')
    else:
        form = AssignmentForm()
    return render(request, 'tracker/assignment_form.html', {'form': form})

# Update
def assignment_update(request, pk):
    assignment = get_object_or_404(Assignment, pk=pk)
    if request.method == "POST":
        form = AssignmentForm(request.POST, instance=assignment)
        if form.is_valid():
            form.save()
            return redirect('assignment_list')
    else:
        form = AssignmentForm(instance=assignment)
    return render(request, 'tracker/assignment_form.html', {'form': form})

# Delete
def assignment_delete(request, pk):
    assignment = get_object_or_404(Assignment, pk=pk)
    if request.method == "POST":
        assignment.delete()
        return redirect('assignment_list')
    return render(request, 'tracker/assignment_confirm_delete.html', {'assignment': assignment})
